package sa3;


public class Pagamento extends Venda {
	
	private int tipoPagamento;

	//CONSTRUTORES
	public Pagamento() {
		
	}

	public Pagamento(int tipoPagamento) {
		this.tipoPagamento = tipoPagamento;
	}
	
	//METODOS
	
	public void selecionarTipoPagamento(int tpag) {
		
		
		tipoPagamento = tpag;
		
		
		if(tpag == 1) {
			System.out.println("Você selecionou a forma de pagamento Dinheiro!");
		}
		else if(tpag == 2) {
			System.out.println("Você selecionou a forma de pagamento Cheque!");
		}
		else if(tpag == 3) {
			System.out.println("Você selecionou a forma de pagamento Cartão!");
		}
		
	}
	
	public void realizarPagamento(Pagamento pag) {
	
		
		if (getTipoPagamento() == 1) {
			System.out.println("Pagamento realizado com Dinheiro!");
		}
		else if (getTipoPagamento() == 2) {
			System.out.println("Pagamento realizado com Cheque!");
		}
		else if(getTipoPagamento() == 3){
			System.out.println("Pagamento realizado com Cartão!");
		}
		
		
	}
	
	
	//GETTERS E SETTERS

	public int getTipoPagamento() {
		return tipoPagamento;
	}

	public void setTipoPagamento(int tipoPagamento) {
		this.tipoPagamento = tipoPagamento;
	}
	
	
	

}
