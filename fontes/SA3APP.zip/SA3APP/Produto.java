package sa3;

public class Produto extends Venda {
	
	private String nome;
	private double preco;
	private int quantidadeEstoque;
	
	//CONTRUTORES
	
	public Produto() {
		
	}


	public Produto(String nome, double preco, int quantidadeEstoque) {
		this.nome = nome;
		this.preco = preco;
		this.quantidadeEstoque = quantidadeEstoque;
	}

	
	//METODOS
	
	public void verificarEstoque (Produto prod){
		int prod1;
		
		prod1 = prod.getQuantidadeEstoque();
		
		if (prod1 == 0) {
			System.out.println("False");
		}
		else {
			System.out.println("True");
		}
		
		
		
		
		
	}
	
	
	
	//GETTERS E SETTERS

	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public double getPreco() {
		return preco;
	}


	public void setPreco(double preco) {
		this.preco = preco;
	}


	public int getQuantidadeEstoque() {
		return quantidadeEstoque;
	}


	public void setQuantidadeEstoque(int quantidadeEstoque) {
		this.quantidadeEstoque = quantidadeEstoque;
	}
	
	
	
	
}

