package sa3;

import java.util.ArrayList;

public class Venda {
	
	private double vlrTotal;
    private ArrayList<Produto> listavenda = new ArrayList<>();
   
	
	
	//Construtores
	public Venda() {
	}

	
	public Venda(double vlrTotal, ArrayList<Produto> listavenda) {
		this.vlrTotal = vlrTotal;
		this.listavenda = listavenda;
	}
	
	
	//METODOS
	
	public void adicionarItemVenda(Produto prod) {
		
		this.listavenda.add(prod);
		
		setVlrTotal(prod.getPreco() * prod.getQuantidadeEstoque());
		
		
	}
	
	
	public void vizualizarVenda() {
		
		
		for(int cont = this.listavenda.size() - 1; cont >= 0; cont--) {
			
			System.out.println("Produto: " + this.listavenda.get(cont).getNome());
		}
		
		
	}
	
	public void concluirVenda(Pagamento pag) {
		
		
		System.out.println("Venda concluida!");
		
		if(pag.getTipoPagamento() == 1) {
			System.out.println("Tipo de pagamento: Dinheiro");
		}
		else if(pag.getTipoPagamento() == 2){
			System.out.println("Tipo de pagamento: Cheque");
		}
		else if (pag.getTipoPagamento() == 3) {
			System.out.println("Tipo de pagamento: Cartão");
		}
		System.out.println("Valor total R$" + this.getVlrTotal());
		
		this.vlrTotal = 0;
		listavenda.clear();
		
		
	}
	
	
	
	
	
	//GETTERS E SETTERS


	public double getVlrTotal() {
		return this.vlrTotal;
	}


	public void setVlrTotal(double vlrTotal) {
		this.vlrTotal += vlrTotal;
	}


	public ArrayList<Produto> getListavenda() {
		return listavenda;
	}


	public void setListavenda(ArrayList<Produto> listavenda) {
		this.listavenda = listavenda;
	}
	
	
	
	
	
	

}
