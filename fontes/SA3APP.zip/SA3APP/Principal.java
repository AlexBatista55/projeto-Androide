package sa3;



public class Principal {
	
	public static void main(String[] args) {
		
		
		Venda venda1 = new Venda();
		Produto produto1 = new Produto("Batata", 10, 1);
		Produto produto2 = new Produto("Cenoura", 15, 2);
		Pagamento pagamento1 = new Pagamento();
		
		
		
		venda1.adicionarItemVenda(produto1);
		
		venda1.adicionarItemVenda(produto2);
		
		pagamento1.selecionarTipoPagamento(2);
			
		pagamento1.realizarPagamento(pagamento1);
		
		venda1.vizualizarVenda();
		
		venda1.concluirVenda(pagamento1);
		
	}

}
